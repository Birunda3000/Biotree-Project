from django.apps import AppConfig


class GerenciarDbConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gerenciar_db'
