from django.contrib import admin
from django.contrib import admin
from django.contrib.auth import admin as auth_admin
from .models import Tag, Vida, Dominio, Reino, Filo, Classe, Ordem, Familia, Genero, Especie, SubEspecie
# Register your models here.

admin.site.register(Tag)
admin.site.register(Vida)
admin.site.register(Dominio)
admin.site.register(Reino)
admin.site.register(Filo)
admin.site.register(Classe)
admin.site.register(Ordem)
admin.site.register(Familia)
admin.site.register(Genero)
admin.site.register(Especie)
admin.site.register(SubEspecie)